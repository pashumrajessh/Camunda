
# Docker Setup – Camunda Loan Approval

## 🔧 Dockerized Components

- `angular-app`: External user task form for Camunda Tasklist
- `java-client`: Starts process and sends message

## 🚀 Quick Start

```bash
docker-compose up --build
```

Then open [http://localhost:4200](http://localhost:4200) to access the Angular app.

Make sure to update your Java client and Angular API endpoints with your actual Camunda SaaS values before building.
