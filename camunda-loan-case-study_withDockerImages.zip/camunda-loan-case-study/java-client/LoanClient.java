import io.camunda.zeebe.client.ZeebeClient;
import java.util.Map;

public class LoanClient {
  public static void main(String[] args) {
    ZeebeClient client = ZeebeClient.newClientBuilder()
        .gatewayAddress("your-camunda-cloud.broker-address:443")
        .usePlaintext()
        .build();

    client.newCreateInstanceCommand()
        .bpmnProcessId("loan_approval_process")
        .latestVersion()
        .variables(Map.of(
            "loanId", "loan123",
            "applicantName", "John Doe",
            "loanAmount", 50000
        ))
        .send()
        .join();

    client.newPublishMessageCommand()
        .messageName("loanApplicationResponse")
        .correlationKey("loan123")
        .variables(Map.of("creditScore", 750))
        .send()
        .join();
  }
}
