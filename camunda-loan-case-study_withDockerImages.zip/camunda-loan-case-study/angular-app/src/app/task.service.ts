import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class TaskService {
  private apiUrl = 'https://api.cloud.camunda.io/tasklist'; // Update with your tasklist endpoint

  constructor(private http: HttpClient) {}

  getCurrentTask(): Observable<any> {
    return this.http.get(`${this.apiUrl}/task`);
  }

  completeTask(taskId: string, payload: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/task/${taskId}/complete`, payload);
  }
}
