import { Component, OnInit } from '@angular/core';
import { TaskService } from '../task.service';

@Component({
  selector: 'app-loan-review-form',
  templateUrl: './loan-review-form.component.html'
})
export class LoanReviewFormComponent implements OnInit {
  task: any;
  formData = { approved: true };

  constructor(private taskService: TaskService) {}

  ngOnInit() {
    this.taskService.getCurrentTask().subscribe(task => {
      this.task = task;
    });
  }

  submit() {
    this.taskService.completeTask(this.task.id, {
      variables: {
        approved: { value: this.formData.approved, type: "Boolean" }
      }
    }).subscribe(() => alert("Task completed"));
  }
}
